import flet as ft
import gui


async def main(page: ft.Page):
    app = gui.MainWindow(page)
    await app.run()

if __name__ == '__main__':
    ft.app(main)