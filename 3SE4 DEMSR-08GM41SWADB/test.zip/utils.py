import os
import aiofiles
import ifaddr
import logging
from datetime import datetime

from icecream import ic


async def search_fw_file():
    current_dir = os.getcwd()

    filename = 'L23B03.bin'
    if filename in os.listdir(current_dir):
        file_path = os.path.join(current_dir, filename)
        async with aiofiles.open(file_path, "rb") as file:
            file_content = await file.read()
        return file_content
    else:
        return False


def ip_check() -> bool:
    config = ifaddr.get_adapters(include_unconfigured=True)
    for a in config:
        ic(a)
    if any(
            True if isinstance(data.ip, str) and '10.8.' in data.ip
            else False for adapter in config for data in adapter.ips
    ):
        logger.info("Машина пользователя настроена на работу в подсети 10.8.X.X")
        return True
    else:
        logger.warning("Машина пользователя не настроена работу в подсети 10.8.X.X")
        return False


def setup_logging():
    current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_filename = f"updater_msata_{current_time}.log"

    logging.basicConfig(
        filename=log_filename,
        filemode='w',
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    logging.getLogger("flet_core").setLevel(logging.WARNING)
    logging.getLogger("flet_runtime").setLevel(logging.WARNING)
    return logging.getLogger()


logger = setup_logging()
